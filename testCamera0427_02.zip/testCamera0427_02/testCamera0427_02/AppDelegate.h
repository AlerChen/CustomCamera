//
//  AppDelegate.h
//  testCamera0427_02
//
//  Created by TopScore-AI on 2018/4/27.
//  Copyright © 2018年 TopScore-AI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

